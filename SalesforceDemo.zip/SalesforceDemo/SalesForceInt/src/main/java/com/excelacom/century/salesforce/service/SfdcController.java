/**
 * @author Sridharan Murugadass
 *
 */
package com.excelacom.century.salesforce.service;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.excelacom.century.salesforce.service.Lead;
import com.excelacom.century.salesforce.service.SalesRepository;


@RestController
public class SfdcController {

	@Autowired
	 DataSource dataSource;

	@Autowired
	SalesRepository salesRepo;

	
	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead create(@RequestBody Lead led) {

		salesRepo.save(led);

		return led;
	}

	@RequestMapping(value = "/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead update(@RequestBody Lead led) {

		Lead lead = salesRepo.findOne(led.getId());
		lead.setLastname(led.getLastname());
		lead.setEmail(led.getEmail());
		lead.setFirstname(led.getFirstname());
		lead.setLeadtype(led.getLeadtype());
		lead.setPhonenumber(led.getPhonenumber());
		lead.setStatus(led.getStatus());
		lead.setRating(led.getRating());
		lead.setWinprobability(led.getWinprobability());
		
		salesRepo.save(lead);

		return led;

	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead delete(@RequestBody Lead led) {

		salesRepo.delete(led.getId());

		return led;

	}

	@RequestMapping(value = "/get", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Iterable<Lead> sales() {

		

		return salesRepo.findAll();
	}
	
	@RequestMapping(value = "/createSales", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead createSales(@RequestBody Lead led) {

		RestTemplate restTemplate = new RestTemplate();

		System.out.println("Begin /POST request!");
		String postUrl = "https://octopusexcelacom-developer-edition.ap5.force.com/services/apexrest/Lead";

		JSONObject json = new JSONObject();
		json.put("LeadType", led.getLeadtype());
		json.put("Status", led.getStatus());
		json.put("FirstName", led.getFirstname());
		json.put("LastName", led.getLastname());
		json.put("Rating", led.getRating());
		json.put("BusinessPhoneNumber", led.getPhonenumber());
		json.put("Email", led.getEmail());
		json.put("WinProbability", led.getWinprobability());

		String inputJson = json.toString();

		System.out.println("Begin /POST request!" + inputJson + json);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> entity = new HttpEntity<String>(inputJson, headers);
		String response = restTemplate.postForObject(postUrl, entity, String.class);

		System.out.println(" /POST ends!" + response);

		led.setId(response.replaceAll("^\"|\"$", ""));

		salesRepo.save(led);

		return led;
	}

	@RequestMapping(value = "/updateSales", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead updateSales(@RequestBody Lead led) {

		RestTemplate restTemplate = new RestTemplate();

		System.out.println("Begin /POST request!");
		String postUrl = "https://octopusexcelacom-developer-edition.ap5.force.com/services/apexrest/Lead";

		JSONObject json = new JSONObject();
		json.put("Id", led.getId());
		json.put("LeadType", led.getLeadtype());
		json.put("Status", led.getStatus());
		json.put("FirstName", led.getFirstname());
		json.put("LastName", led.getLastname());
		json.put("Rating", led.getRating());
		json.put("BusinessPhoneNumber", led.getPhonenumber());
		json.put("Email", led.getEmail());
		json.put("WinProbability", led.getWinprobability());

		String inputJson = json.toString();

		System.out.println("Begin /POST request!" + inputJson + json);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> entity = new HttpEntity<String>(inputJson, headers);
		ResponseEntity<String> response = restTemplate.exchange(postUrl, HttpMethod.PUT, entity, String.class);

		System.out.println(" /POST ends!" + response);

		salesRepo.save(led);

		return led;
	}

	@RequestMapping(value = "/deleteSales/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteSales(@PathVariable("id") String id) {

		RestTemplate restTemplate = new RestTemplate();

		String postUrl = "https://octopusexcelacom-developer-edition.ap5.force.com/services/apexrest/Lead/{id}";

		System.out.println(id);

		Map<String, String> params = new HashMap<String, String>();
		params.put("id", id);

		restTemplate.delete(postUrl, params);

		salesRepo.delete(id);

		return new ResponseEntity(HttpStatus.OK);
	}

	

}
