/**
 * @author Sridharan Murugadass
 *
 */
package com.excelacom.century.salesforce.service;


import org.springframework.data.repository.CrudRepository;
import com.excelacom.century.salesforce.service.Lead;


public interface SalesRepository extends CrudRepository<Lead, String> {

}
