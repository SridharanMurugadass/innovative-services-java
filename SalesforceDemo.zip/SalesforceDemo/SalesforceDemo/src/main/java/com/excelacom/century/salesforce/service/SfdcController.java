/**
 * @author Sridharan Murugadass
 *
 */
package com.excelacom.century.salesforce.service;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.excelacom.century.salesforce.service.Lead;
import com.excelacom.century.salesforce.service.SalesRepository;


@RestController
public class SfdcController {

	@Autowired
	 DataSource dataSource;

	@Autowired
	SalesRepository salesRepo;

	
	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead create(@RequestBody Lead led) {

		salesRepo.save(led);

		return led;
	}

	@RequestMapping(value = "/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead update(@RequestBody Lead led) {

		salesRepo.save(led);

		return led;

	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Lead delete(@RequestBody Lead led) {

		salesRepo.delete(led.getId());

		return led;

	}

	@RequestMapping(value = "/get", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Iterable<Lead> sales() {

		

		return salesRepo.findAll();
	}

	

}
